
// Declaración de Función
sumar();
function sumar() {
    console.log(10 + 10);
}



// Expresión de la función
sumar2();
const sumar2 = function() {
    console.log( 3 + 3);
}


