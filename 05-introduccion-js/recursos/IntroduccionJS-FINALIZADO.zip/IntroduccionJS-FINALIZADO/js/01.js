// Variables

var producto = 'Audifonos Gamer'; // Iniciar variable y asignarle valor

var disponible; // iniciamos la variable pero sin valor.

// producto = true; // Reasignando el valor de la variable

disponible = true;


var producto1 = 'Computadora', 
    disponible1 = true,
    categoria = 'Computadoras';


// var 1disponible;
var disponible_;

// Estilos para las variables
var nombre_producto = 'Monitor HD'; // underscore
var nombreProducto = 'Monitor HD'; // Camelcase
var NombreProducto = 'Monitor HD'; // Pascal Case
var nombreproducto = 'MonitorHD'; 


console.log(PRODUCTO);