// Booleans

const boolean1 = true;
const boolean2 = false;

console.log(boolean1);
console.log(boolean2);
