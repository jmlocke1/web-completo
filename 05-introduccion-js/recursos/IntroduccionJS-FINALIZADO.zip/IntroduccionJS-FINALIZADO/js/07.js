// Orden de las operaciones

let resultado;

resultado = (20 + 30) * 2;

resultado = ( 600 + 600 ) * 1.05; 


// console.log(resultado);

// Incrementos

let puntaje = 10;

// Incremento en 1 ++

puntaje += 10;

console.log(puntaje);
