// Objeto Math

let resultado;

resultado = Math.PI;
resultado = Math.round(2.5);
resultado = Math.ceil(2.1); // Ceil siempre redondea hacia arriba
resultado = Math.floor(2.9); // Floor siempre redondea hacia abajo
resultado = Math.sqrt(144);
resultado = Math.abs(-200);
resultado = Math.min( 3, 5, 1, 8 , 2, 10 );
resultado = Math.max( 3, 5, 1, 8 , 2, 10 );
resultado = Math.random();
resultado = Math.floor( Math.random() * 30 );

console.log(resultado);