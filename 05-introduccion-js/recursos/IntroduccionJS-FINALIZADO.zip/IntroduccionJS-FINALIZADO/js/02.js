// Variables con let

let producto = 'Audifonos Gamer'; // Iniciar variable y asignarle valor

let disponible; // iniciamos la variable pero sin valor.

// producto = true; // Reasignando el valor de la variable

disponible = true;


let producto1 = 'Computadora', 
    disponible1 = true,
    categoria = 'Computadoras';


// let 1disponible;
let disponible_;

// Estilos para las variables
let nombre_producto = 'Monitor HD'; // underscore
let nombreProducto = 'Monitor HD'; // Camelcase
let NombreProducto = 'Monitor HD'; // Pascal Case
let nombreproducto = 'MonitorHD'; 
