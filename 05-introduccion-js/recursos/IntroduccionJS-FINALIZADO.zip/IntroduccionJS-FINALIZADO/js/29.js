const numero1 = 20;
const numero3 = 30;


console.log(numero1);

try {
    console.log(numero2);
} catch (error) {
    console.log(error);
}

console.log(numero3);