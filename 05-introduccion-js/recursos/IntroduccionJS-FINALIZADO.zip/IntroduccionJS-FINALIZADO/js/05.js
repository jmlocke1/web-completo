// Números

const numero1 = 100;
const numero2 = 200;
const numero3 = 9;
const numero4 = 3;
const numero5 = -5;

console.log(numero1 + numero2);
console.log(numero2 - numero1);
console.log(numero2 * numero1);
console.log(numero2 / numero1);
console.log(numero3 % numero4);

