// Variables con let

const producto = 'Audifonos Gamer'; // Iniciar variable y asignarle valor

let disponible = true; // iniciamos la variable pero sin valor.

// producto = true; // Reasignando el valor de la variable

disponible = true;


const producto1 = 'Computadora', 
    disponible1 = true,
    categoria = 'Computadoras';


// const 1disponible;
const disponible_ = true;

// Estilos para las variables
const nombre_producto = 'Monitor HD'; // underscore
const nombreProducto = 'Monitor HD'; // Camelcase
const NombreProducto = 'Monitor HD'; // Pascal Case
const nombreproducto = 'MonitorHD'; 
