const numero1 = 20;
const numero2 = "20";


console.log( parseInt(numero2) ); // parseInt() es una función
console.log( numero1.toString() ); // .toString() es un método