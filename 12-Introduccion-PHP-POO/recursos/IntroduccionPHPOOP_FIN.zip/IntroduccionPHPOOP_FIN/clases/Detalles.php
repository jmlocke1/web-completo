<?php

namespace App;

class Detalles {
    public function __construct()
    {
        echo "Desde la clase de Detalles.php";
    }
}