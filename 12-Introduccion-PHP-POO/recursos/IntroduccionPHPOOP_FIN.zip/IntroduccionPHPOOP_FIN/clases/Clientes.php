<?php

namespace App;

class Clientes {
    public function __construct()
    {
        echo "Desde la clase de Clientes.php";
    }
}