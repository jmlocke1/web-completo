<?php include 'includes/header.php';


$numero1 = 30;
echo ++$numero1;

$numero1 += 5;
echo $numero1;

$numero2 = 30;
echo --$numero2;


include 'includes/footer.php';