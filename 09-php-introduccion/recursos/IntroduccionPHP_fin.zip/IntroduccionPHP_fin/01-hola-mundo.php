<?php include 'includes/header.php'; ?>

<?php echo "hola Mundo"; ?>

<br>

<?php echo("Hola Mundo");


print("Hola Mundo");

print "Hola Mundo";

print_r("Hola Mundo");

var_dump("Hola Mundo");



include 'includes/footer.php'; ?>